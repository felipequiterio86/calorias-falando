# 🥗 Calorias Falando

App (PWA) para acompanhar calorias **falando** o que você comeu. Você diz, por exemplo:
"150 gramas de arroz, 100 gramas de frango grelhado e 50 gramas de feijão" e o app calcula as calorias,
mostra para confirmar e grava no diário com data e hora.

Inclui: cadastro com e-mail e senha, IMC e TMB (calculados ou digitados a partir de uma balança de bioimpedância),
diário do dia e fechamentos semanal, mensal e anual.

**Custo: R$ 0** usando os planos gratuitos de Supabase (login + banco + função), Google Gemini (IA) e GitHub Pages (hospedagem).

---

## Passo a passo (cerca de 20 minutos)

### 1. Supabase (login, banco de dados e função da IA)
1. Crie uma conta grátis em https://supabase.com e clique em **New project** (anote a senha do banco; escolha a região São Paulo).
2. No menu **SQL Editor > New query**, cole o conteúdo de `supabase/schema.sql` e clique em **Run**.
3. Em **Project Settings > API**, copie a **Project URL** e a chave **anon public**.
4. Abra o arquivo `config.js` deste projeto e cole esses dois valores.
5. (Opcional, para testar rápido) Em **Authentication > Sign In / Providers > Email**, desligue "Confirm email". Para uso real, deixe ligado.

### 2. Chave gratuita do Gemini
1. Acesse https://aistudio.google.com/apikey e clique em **Create API key**.
2. Guarde a chave. Ela **não** vai no app, só no Supabase (passo 3).

### 3. Função da IA no Supabase
1. No Supabase, vá em **Edge Functions > Deploy a new function > Via Editor**.
2. Nome da função: `parse-meal` (exatamente assim).
3. Apague o código de exemplo, cole o conteúdo de `supabase/functions/parse-meal/index.ts` e clique em **Deploy**.
4. Em **Edge Functions > Secrets**, adicione `GEMINI_API_KEY` com a chave do passo 2.
   (Se o Google descontinuar o modelo padrão, adicione também `GEMINI_MODEL` com o nome de um modelo Flash atual, por exemplo `gemini-3.5-flash-lite`.)

### 4. Hospedagem gratuita (GitHub Pages)
1. Crie uma conta em https://github.com e um repositório **público** novo (ex.: `calorias-falando`).
2. Envie todos os arquivos desta pasta (exceto `supabase/` e este README, se quiser) usando **Add file > Upload files**.
3. Em **Settings > Pages**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve.
4. Após 1–2 minutos, seu app estará em `https://SEU-USUARIO.github.io/calorias-falando/`.

Alternativas igualmente gratuitas: Cloudflare Pages ou Netlify (basta arrastar a pasta).

### 5. Usar no celular
Abra o endereço no **Chrome (Android)** e use **⋮ > Instalar app / Adicionar à tela inicial**.
No iPhone, o ditado no navegador é limitado: use o microfone do teclado no campo de texto.

---

## Como funciona
- **Voz:** o navegador converte sua fala em texto (Web Speech API, pt-BR, grátis).
- **Calorias:** o texto vai para a função `parse-meal`, que consulta o Gemini e devolve cada alimento com kcal, proteína, carboidrato e gordura. Se você não disser o peso, ele estima uma porção típica e marca como "estimado".
- **Segurança:** cada pessoa só enxerga os próprios dados (regras RLS no `schema.sql`). A chave do Gemini fica só no servidor e só usuários logados chamam a função.
- **TMB:** fórmula de Mifflin-St Jeor, ou o valor que você digitar da balança de bioimpedância.

## Limites do plano gratuito (valem em 2026, confira nos sites)
- Supabase: projetos gratuitos podem ser pausados após período sem uso; basta reativar no painel.
- Gemini: o plano gratuito tem limite de requisições por minuto/dia, suficiente para uso pessoal.

## Aviso
As calorias são estimativas e o app não substitui acompanhamento de nutricionista ou médico.

## Próximos passos possíveis
Integração com Google Fit / Samsung Health / FitDay, editar uma refeição, metas de calorias e proteína, exportar relatório em PDF.
