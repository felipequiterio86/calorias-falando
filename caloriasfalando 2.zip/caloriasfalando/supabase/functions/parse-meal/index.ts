// Supabase Edge Function: parse-meal
// Recebe { text } com o que a pessoa falou e devolve os itens com calorias (via Gemini).
// A chave do Gemini fica guardada como secret no Supabase (nunca vai para o navegador).

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

const PROMPT = `Você é um nutricionista que calcula calorias de refeições brasileiras.
O usuário falou o que comeu, normalmente com o peso de cada alimento.
Regras:
- Separe cada alimento em um item.
- Use o peso informado em gramas (converta kg, colher, xícara etc. para gramas se necessário).
- Se o peso NÃO foi informado, estime uma porção típica e marque "estimated": true.
- Calcule kcal, proteínas, carboidratos e gorduras para o peso do item, considerando o modo de preparo dito (cozido, frito, grelhado, cru...). Se não foi dito, assuma o mais comum no Brasil.
- Use valores da tabela TACO / USDA como referência.
- Nomes dos itens em português, curtos.
- Responda somente no formato JSON pedido.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  try {
    const { text } = await req.json();
    if (typeof text !== "string" || text.trim().length < 2 || text.length > 800) {
      return json({ error: "Texto inválido." }, 400);
    }

    const key = Deno.env.get("GEMINI_API_KEY");
    if (!key) return json({ error: "GEMINI_API_KEY não configurada no Supabase." }, 500);
    const model = Deno.env.get("GEMINI_MODEL") ?? "gemini-3.5-flash-lite";

    const body = {
      systemInstruction: { parts: [{ text: PROMPT }] },
      contents: [{ role: "user", parts: [{ text: text.trim() }] }],
      generationConfig: {
        temperature: 0.2,
        responseMimeType: "application/json",
        responseSchema: {
          type: "OBJECT",
          properties: {
            items: {
              type: "ARRAY",
              items: {
                type: "OBJECT",
                properties: {
                  name: { type: "STRING" },
                  grams: { type: "NUMBER" },
                  kcal: { type: "NUMBER" },
                  protein_g: { type: "NUMBER" },
                  carbs_g: { type: "NUMBER" },
                  fat_g: { type: "NUMBER" },
                  estimated: { type: "BOOLEAN" },
                },
                required: ["name", "grams", "kcal", "protein_g", "carbs_g", "fat_g", "estimated"],
              },
            },
          },
          required: ["items"],
        },
      },
    };

    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify(body),
      },
    );

    if (!r.ok) {
      const detail = await r.text();
      console.error("Gemini error", r.status, detail);
      return json({ error: `Erro na IA (${r.status}). Tente novamente.` }, 502);
    }

    const data = await r.json();
    const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "{}";
    const parsed = JSON.parse(raw);
    const items = (parsed.items ?? []).map((i: any) => ({
      name: String(i.name ?? "Item"),
      grams: Math.round(Number(i.grams) || 0),
      kcal: Math.round(Number(i.kcal) || 0),
      protein_g: Math.round((Number(i.protein_g) || 0) * 10) / 10,
      carbs_g: Math.round((Number(i.carbs_g) || 0) * 10) / 10,
      fat_g: Math.round((Number(i.fat_g) || 0) * 10) / 10,
      estimated: Boolean(i.estimated),
    }));

    if (!items.length) return json({ error: "Não consegui identificar alimentos nessa frase." }, 422);

    const total_kcal = items.reduce((s: number, i: any) => s + i.kcal, 0);
    return json({ items, total_kcal });
  } catch (e) {
    console.error(e);
    return json({ error: "Falha ao processar a refeição." }, 500);
  }
});
