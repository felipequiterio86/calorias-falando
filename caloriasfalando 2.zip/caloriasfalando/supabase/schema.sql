-- Cole este arquivo inteiro no Supabase: SQL Editor > New query > Run

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  weight_kg numeric,
  height_cm numeric,
  age int,
  sex text check (sex in ('M','F')),
  imc numeric,
  tmb numeric,
  tmb_manual boolean default false,
  updated_at timestamptz default now()
);

create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade default auth.uid(),
  eaten_at timestamptz not null default now(),
  description text not null,
  total_kcal numeric not null,
  items jsonb not null default '[]'::jsonb,
  created_at timestamptz default now()
);

create index if not exists meals_user_time_idx on public.meals (user_id, eaten_at desc);

alter table public.profiles enable row level security;
alter table public.meals enable row level security;

drop policy if exists "profiles_own" on public.profiles;
create policy "profiles_own" on public.profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "meals_own" on public.meals;
create policy "meals_own" on public.meals
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
